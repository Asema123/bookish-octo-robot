package com.example.demo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MathUtilsTest {

    @Test
    public void testMultiply() {
        MathUtils mathUtils = new MathUtils();
        assertEquals(6, mathUtils.multiply(2, 3), "2*3=6");
        assertEquals(0, mathUtils.multiply(0, 5), "0*5=0");
        assertEquals(-15, mathUtils.multiply(-3, 5), "-3*5=-15");
    }

    @Test
    public void testDivide() {
        MathUtils mathUtils = new MathUtils();
        assertEquals(2, mathUtils.divide(6, 3), "6/3=2");
        assertEquals(-2, mathUtils.divide(-6, 3), "-6/3=-2");
        assertThrows(ArithmeticException.class, () -> mathUtils.divide(1, 0), "Деление на ноль должно вызывать ArithmeticException");
    }
}