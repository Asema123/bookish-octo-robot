package com.example.demo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringProcessorTest {

    @Test
    public void testReverseString() {
        StringProcessor processor = new StringProcessor();
        assertEquals("olleh", processor.reverseString("hello"));
        assertThrows(IllegalArgumentException.class, () -> processor.reverseString(null));
    }

    @Test
    public void testCountVowels() {
        StringProcessor processor = new StringProcessor();
        assertEquals(5, processor.countVowels("education"));
        assertEquals(0, processor.countVowels("bcdfg"));
        assertThrows(IllegalArgumentException.class, () -> processor.countVowels(null));
    }

    @Test
    public void testIsPalindrome() {
        StringProcessor processor = new StringProcessor();
        assertTrue(processor.isPalindrome("Madam"));
        assertTrue(processor.isPalindrome("Step on no pets"));
        assertFalse(processor.isPalindrome("hello"));
        assertThrows(IllegalArgumentException.class, () -> processor.isPalindrome(null));
    }
}
