package com.example.demo;

import org.junit.jupiter.api.*;

public class EquationSolverTest {

    @Test
    void testSolveEquation() {
        double result = EquationSolver.solveEquation(2, -6);
        Assertions.assertEquals(3, result, "Результат должен быть 3");
    }

    @Test
    void testSolveEquationWithZeroA() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            EquationSolver.solveEquation(0, 5);
        }, "Ожидается исключение, если a равно 0");
    }
}
