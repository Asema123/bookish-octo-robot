package com.example.demo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class AdvancedMathUtilsTest {

    @Test
    public void testCalculateSquareRoot() {
        AdvancedMathUtils mathUtils = new AdvancedMathUtils();
        assertEquals(3.0, mathUtils.calculateSquareRoot(9), 0.0001);
        assertThrows(NegativeNumberException.class, () -> mathUtils.calculateSquareRoot(-1));
    }

    @Test
    public void testCalculateLogarithm() {
        AdvancedMathUtils mathUtils = new AdvancedMathUtils();
        assertEquals(1.0, mathUtils.calculateLogarithm(10), 0.0001);
        assertThrows(IllegalArgumentException.class, () -> mathUtils.calculateLogarithm(0));
    }

    @Test
    public void testCalculateNthRoot() {
        AdvancedMathUtils mathUtils = new AdvancedMathUtils();
        assertEquals(3.0, mathUtils.calculateNthRoot(27, 3), 0.0001);
        assertThrows(IllegalArgumentException.class, () -> mathUtils.calculateNthRoot(27, 0));
    }
}