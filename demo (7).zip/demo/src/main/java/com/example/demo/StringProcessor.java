package com.example.demo;
class StringProcessor {

    public String reverseString(String input) {
        if (input == null || input.isEmpty()) {
            throw new IllegalArgumentException("Input string cannot be null or empty.");
        }
        return new StringBuilder(input).reverse().toString();
    }

    public int countVowels(String input) {
        if (input == null) {
            throw new IllegalArgumentException("Input string cannot be null.");
        }
        long count = input.toLowerCase().chars()
                .filter(c -> "aeiou".indexOf(c) != -1)
                .count();
        return (int) count;
    }

    public boolean isPalindrome(String input) {
        if (input == null) {
            throw new IllegalArgumentException("Input string cannot be null.");
        }
        String cleaned = input.replaceAll("\\s+", "").toLowerCase();
        return cleaned.equals(new StringBuilder(cleaned).reverse().toString());
    }
}
