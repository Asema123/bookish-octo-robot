package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquationSolver {
	public static double solveEquation(double a, double b) {
		if (a == 0) {
			throw new IllegalArgumentException("a!=0");
		}
		return -b / a;
	}
}

